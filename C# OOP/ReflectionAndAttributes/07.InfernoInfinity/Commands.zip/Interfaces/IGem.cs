﻿
public interface IGem
{
    Clarity Clarity { get; }

    int BonusStrength { get;  }

    int BonusAgility { get; }

    int BonusVitality { get; }
}


