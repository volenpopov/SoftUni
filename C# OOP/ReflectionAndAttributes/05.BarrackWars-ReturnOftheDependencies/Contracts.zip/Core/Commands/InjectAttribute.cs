﻿
using System;

public class InjectAttribute : Attribute
{ }

