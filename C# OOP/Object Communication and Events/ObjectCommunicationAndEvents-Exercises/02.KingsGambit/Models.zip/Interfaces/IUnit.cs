﻿namespace _02.KingsGambit.Interfaces
{
    public interface ISubordinate : IAttackable, INameable, IMortal
    { }
}
