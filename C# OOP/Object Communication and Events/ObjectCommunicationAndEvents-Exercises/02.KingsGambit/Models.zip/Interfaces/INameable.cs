﻿namespace _02.KingsGambit
{
    public interface INameable
    {
        string Name { get; }
    }
}
