﻿namespace _02.KingsGambit.Interfaces
{
    public interface IMortal
    {
        bool IsAlive { get; }

        void Die();
    }
}
