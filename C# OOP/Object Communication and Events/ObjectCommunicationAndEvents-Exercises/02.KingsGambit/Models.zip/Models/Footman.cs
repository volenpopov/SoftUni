﻿using _02.KingsGambit.Models;

namespace _02.KingsGambit
{
    public class Footman : Subordinate
    {
        public Footman(string name)
            : base(name, "panicking")
        { }
    }
}
