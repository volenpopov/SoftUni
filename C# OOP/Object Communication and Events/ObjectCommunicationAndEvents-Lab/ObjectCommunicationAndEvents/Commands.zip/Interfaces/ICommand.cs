﻿namespace ObjectCommunicationAndEvents
{
    public interface ICommand
    {
        void Execute();
    }
}
