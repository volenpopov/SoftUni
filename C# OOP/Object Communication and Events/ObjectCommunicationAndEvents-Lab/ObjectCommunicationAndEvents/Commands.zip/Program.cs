﻿using ObjectCommunicationAndEvents;
using System;

namespace Object_Communication_and_Events_Lab
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger combatLog = new CombatLogger();
            Logger eventLog = new EventLogger();

            combatLog.SetSuccessor(eventLog);

            AbstractHero warrior = new Warrior("Pesho", 10, combatLog);
            ITarget dragon = new Dragon("Charizard", 50, 15, combatLog);

            IExecutor executor = new CommandExecutor();
            ICommand setTarget = new TargetCommand(warrior, dragon);
            ICommand attack = new AttackCommand(warrior);
            executor.ExecuteCommand(setTarget);
            executor.ExecuteCommand(attack);
        }
    }
}
